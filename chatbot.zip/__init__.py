import sys
sys.path.append('/home/ubuntu/chatbot')
from flask import Flask, request, render_template
from botweb import Flaskchatbot

app = Flask(__name__)
qnalist = []

def create_app():
  @app.route('/', methods=['GET'])
  def index():
      return render_template('index.html')
  
  @app.route('/chatbot', methods=['GET','post'])
  def chattingwithbot():
      if request.method == 'POST':
          question = request.form['question']
          answer = Flaskchatbot.to_website(question)
          qnalist.append((question,answer))
          return render_template('chatbot.html',qnalist = qnalist)
      else:
          return render_template('chatbot.html')
  return app

if __name__ == '__main__':
    app.run(host = '0.0.0.0', port = 5000)


    
    