import threading
import json
import sys
sys.path.append('/home/ubuntu/chatbot/')
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
from config.DatabaseConfig import *
from utils.Database import Database
from utils.BotServer import BotServer
from utils.Preprocess import Preprocess
from models.intent.IntentModel import IntentModel
from models.ner.NerModel import NerModel
from utils.FindAnswer import FindAnswer

p = Preprocess(word2index_dic='./train_tools/dict/chatbot_dict.bin')

intent = IntentModel(model_name='./intent_model.h5',proprocess=p)

ner = NerModel(model_name='./ner_model.h5',proprocess = p)

class Flaskchatbot:        
    def to_website(question):
        db = Database(
        host = DB_HOST, user = DB_USER, password = DB_PASSWORD, db_name = DB_NAME
    )
        try:
            db.connect()
            query = question
            print(query)#test#
            
            intent_predict = intent.predict_class(query)
            intent_name = intent.labels[intent_predict]
            ner_predicts = ner.predict(query)
            ner_tags = ner.predict_tags(query)
            try:
                f = FindAnswer(db)
                answer_text, answer_image = f.search(intent_name, ner_tags)
                answer = f.tag_to_word(ner_predicts, answer_text)
            except:
                answer = "이해하지 못하였습니다. 조금 더 배우고 오겠습니다."
                answer_image = None
            
            print(answer)
            return answer

            
        except Exception as ex:
            print(ex)
            
        finally:
            if db is not None:
                db.close
